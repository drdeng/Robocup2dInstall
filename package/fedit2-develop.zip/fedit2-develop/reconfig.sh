#!/bin/sh

./bootstrap
./configure --prefix=$HOME/local

